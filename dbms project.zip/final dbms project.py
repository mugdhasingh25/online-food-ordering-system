import tkinter as tk
from tkinter import messagebox
import mysql.connector

# Database connection details
db_config = {
    'host': 'localhost',
    'user': 'root',
    'password': 'Riya@232004',
    'database': 'food_ordering_system'
}

# Define the font and size
default_font = ("Helvetica", 14)  # Change the font and size as desired

# Helper functions
def register_user(username, password, email, phone_number):
    conn = mysql.connector.connect(**db_config)
    cursor = conn.cursor()
    query = "INSERT INTO users (username, password, email, phone_number) VALUES (%s, %s, %s, %s)"
    try:
        cursor.execute(query, (username, password, email, phone_number))
        conn.commit()
        messagebox.showinfo("Success", "Registration successful!")
    except mysql.connector.Error as e:
        messagebox.showerror("Error", f"Failed to register user: {e}")
    finally:
        cursor.close()
        conn.close()

def login_user(username, password):
    conn = mysql.connector.connect(**db_config)
    cursor = conn.cursor()
    query = "SELECT * FROM users WHERE username = %s AND password = %s"
    try:
        cursor.execute(query, (username, password))
        user = cursor.fetchone()
        return user
    except mysql.connector.Error as e:
        messagebox.showerror("Error", f"Failed to login: {e}")
        return None
    finally:
        cursor.close()
        conn.close()

def fetch_categories():
    conn = mysql.connector.connect(**db_config)
    cursor = conn.cursor()
    query = "SELECT * FROM menu_categories"
    try:
        cursor.execute(query)
        categories = cursor.fetchall()
        return categories
    except mysql.connector.Error as e:
        messagebox.showerror("Error", f"Failed to fetch categories: {e}")
        return []
    finally:
        cursor.close()
        conn.close()

def fetch_items(category_id):
    conn = mysql.connector.connect(**db_config)
    cursor = conn.cursor()
    query = "SELECT * FROM menu_items WHERE category_id = %s"
    try:
        cursor.execute(query, (category_id,))
        items = cursor.fetchall()
        return items
    except mysql.connector.Error as e:
        messagebox.showerror("Error", f"Failed to fetch items: {e}")
        return []
    finally:
        cursor.close()
        conn.close()

def add_to_cart(user_id, item_id, quantity):
    conn = mysql.connector.connect(**db_config)
    cursor = conn.cursor()
    query = "INSERT INTO cart (user_id, item_id, quantity) VALUES (%s, %s, %s) ON DUPLICATE KEY UPDATE quantity = quantity + %s"
    try:
        cursor.execute(query, (user_id, item_id, quantity, quantity))
        conn.commit()
    except mysql.connector.Error as e:
        messagebox.showerror("Error", f"Failed to add to cart: {e}")
    finally:
        cursor.close()
        conn.close()

def remove_from_cart(user_id, item_id):
    conn = mysql.connector.connect(**db_config)
    cursor = conn.cursor()
    query = "DELETE FROM cart WHERE user_id = %s AND item_id = %s"
    try:
        cursor.execute(query, (user_id, item_id))
        conn.commit()
    except mysql.connector.Error as e:
        messagebox.showerror("Error", f"Failed to remove from cart: {e}")
    finally:
        cursor.close()
        conn.close()

def get_cart_items(user_id):
    conn = mysql.connector.connect(**db_config)
    cursor = conn.cursor()
    query = "SELECT menu_items.item_name, cart.quantity, menu_items.price FROM cart JOIN menu_items ON cart.item_id = menu_items.item_id WHERE cart.user_id = %s"
    try:
        cursor.execute(query, (user_id,))
        cart_items = cursor.fetchall()
        return cart_items
    except mysql.connector.Error as e:
        messagebox.showerror("Error", f"Failed to fetch cart items: {e}")
        return []
    finally:
        cursor.close()
        conn.close()

def calculate_total(cart_items):
    return sum(item[1] * item[2] for item in cart_items)

# Main application class
class FoodOrderingApp:
    def __init__(self):
        self.window = tk.Tk()
        self.window.title("Online Food Ordering System")
        self.current_frame = None
        self.user = None
        
        # Start with the registration page
        self.show_registration_page()
        
        # Main loop
        self.window.mainloop()
    
    def show_registration_page(self):
        # Remove any existing frame
        if self.current_frame:
            self.current_frame.destroy()
        
        # Create a new frame
        frame = tk.Frame(self.window)
        frame.pack()
        
        # Username entry
        tk.Label(frame, text="Username:", font=default_font).grid(row=0, column=0)
        username_entry = tk.Entry(frame, font=default_font)
        username_entry.grid(row=0, column=1)
        
        # Password entry
        tk.Label(frame, text="Password:", font=default_font).grid(row=1, column=0)
        password_entry = tk.Entry(frame, show="*", font=default_font)
        password_entry.grid(row=1, column=1)
        
        # Email entry
        tk.Label(frame, text="Email:", font=default_font).grid(row=2, column=0)
        email_entry = tk.Entry(frame, font=default_font)
        email_entry.grid(row=2, column=1)
        
        # Phone number entry
        tk.Label(frame, text="Phone Number:", font=default_font).grid(row=3, column=0)
        phone_entry = tk.Entry(frame, font=default_font)
        phone_entry.grid(row=3, column=1)
        
        # Register button
        register_button = tk.Button(frame, text="Register", font=default_font, command=lambda: register_user(username_entry.get(), password_entry.get(), email_entry.get(), phone_entry.get()))
        register_button.grid(row=4, column=1, pady=10)
        
        # Login button
        login_button = tk.Button(frame, text="Already have an account? Log in", font=default_font, command=self.show_login_page)
        login_button.grid(row=5, column=1, pady=10)
        
        self.current_frame = frame
    
    def show_login_page(self):
        # Remove any existing frame
        if self.current_frame:
            self.current_frame.destroy()
        
        # Create a new frame
        frame = tk.Frame(self.window)
        frame.pack()
        
        # Username entry
        tk.Label(frame, text="Username:", font=default_font).grid(row=0, column=0)
        username_entry = tk.Entry(frame, font=default_font)
        username_entry.grid(row=0, column=1)
        
        # Password entry
        tk.Label(frame, text="Password:", font=default_font).grid(row=1, column=0)
        password_entry = tk.Entry(frame, show="*", font=default_font)
        password_entry.grid(row=1, column=1)
        
        # Login button
        login_button = tk.Button(frame, text="Login", font=default_font, command=lambda: self.login(username_entry.get(), password_entry.get()))
        login_button.grid(row=2, column=1, pady=10)
        
        self.current_frame = frame
    
    def login(self, username, password):
        user = login_user(username, password)
        if user:
            self.user = user
            messagebox.showinfo("Success", "Login successful!")
            self.show_menu_categories()
        else:
            messagebox.showerror("Error", "Invalid username or password")
    
    def show_menu_categories(self):
        # Remove any existing frame
        if self.current_frame:
            self.current_frame.destroy()
        
        # Create a new frame
        frame = tk.Frame(self.window)
        frame.pack()
        
        # Get menu categories
        categories = fetch_categories()
        
        # Display categories
        for i, (category_id, category_name) in enumerate(categories):
            button = tk.Button(frame, text=category_name, font=default_font, command=lambda cid=category_id: self.show_menu_items(cid))
            button.grid(row=i, column=0, pady=5)
        
        # Set the current frame
        self.current_frame = frame
    
    def show_menu_items(self, category_id):
        # Remove any existing frame
        if self.current_frame:
            self.current_frame.destroy()
        
        # Create a new frame
        frame = tk.Frame(self.window)
        frame.pack()
        
        # Get menu items for the selected category
        items = fetch_items(category_id)
        
        # Display items
        for i, (item_id, _, item_name, price) in enumerate(items):
            item_label = f"{item_name} - ${price:.2f}"
            tk.Label(frame, text=item_label, font=default_font).grid(row=i, column=0)
            
            # Add to cart button
            add_button = tk.Button(frame, text="Add to Cart", font=default_font, command=lambda iid=item_id: self.add_to_cart(iid))
            add_button.grid(row=i, column=1)
        
        # Add back button
        back_button = tk.Button(frame, text="Back", font=default_font, command=self.show_menu_categories)
        back_button.grid(row=len(items), column=0, pady=10)
        
        # Add view cart button
        view_cart_button = tk.Button(frame, text="View Cart", font=default_font, command=self.show_cart)
        view_cart_button.grid(row=len(items), column=1, pady=10)
        
        # Set the current frame
        self.current_frame = frame
    
    def add_to_cart(self, item_id):
        # Add one item at a time to the cart
        quantity = 1
        add_to_cart(self.user[0], item_id, quantity)
        messagebox.showinfo("Success", "Item added to cart!")
    
    def show_cart(self):
        # Remove any existing frame
        if self.current_frame:
            self.current_frame.destroy()
        
        # Create a new frame
        frame = tk.Frame(self.window)
        frame.pack()
        
        # Get cart items for the user
        cart_items = get_cart_items(self.user[0])
        
        # Display cart items
        for i, (item_name, quantity, price) in enumerate(cart_items):
            item_label = f"{item_name} - ${price:.2f} x {quantity}"
            tk.Label(frame, text=item_label, font=default_font).grid(row=i, column=0)
            
            # Create a button to remove an item from the cart
            remove_button = tk.Button(frame, text="Remove", font=default_font, command=lambda idx=i: self.remove_item_from_cart(cart_items[idx][0]))
            remove_button.grid(row=i, column=1)
        
        # Add back button
        back_button = tk.Button(frame, text="Back", font=default_font, command=self.show_menu_categories)
        back_button.grid(row=len(cart_items), column=0, pady=10)
        
        # Add checkout button
        checkout_button = tk.Button(frame, text="Checkout", font=default_font, command=self.checkout)
        checkout_button.grid(row=len(cart_items), column=1, pady=10)
        
        # Set the current frame
        self.current_frame = frame
    
    def remove_item_from_cart(self, item_id):
        # Remove an item from the user's cart
        remove_from_cart(self.user[0], item_id)
        messagebox.showinfo("Success", "Item removed from cart!")
        # Refresh the cart page after removing the item
        self.show_cart()
    
    def checkout(self):
        # Calculate the total amount for the cart
        cart_items = get_cart_items(self.user[0])
        total = calculate_total(cart_items)
        
        # Display the total amount in a message box
        messagebox.showinfo("Checkout", f"Total amount: ${total:.2f}")
        # Further actions, such as payment, can be added here

# Start the application
if __name__ == "__main__":
    app = FoodOrderingApp()
